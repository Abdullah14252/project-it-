<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_DBproject1 = "localhost";
$database_DBproject1 = "usersinfo";
$username_DBproject1 = "root";
$password_DBproject1 = "";
$DBproject1 = mysql_pconnect($hostname_DBproject1, $username_DBproject1, $password_DBproject1) or trigger_error(mysql_error(),E_USER_ERROR); 
?>