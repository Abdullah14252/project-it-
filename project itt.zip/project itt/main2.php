<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style3 {
	font-size: 36pt;
	color: #00254A;
	font-family: "Times New Roman", Times, serif;
}
.style6 {color: #00254A; font-family: "Times New Roman", Times, serif; font-size: 24px; }
.style7 {color: #00254A; font-family: "Times New Roman", Times, serif; font-size: 24px; font-weight: bold; }
.style8 {font-size: 24px}
-->
</style></head>

<body>
<div align="center">
  <table width="2295" cellspacing="2">
    <tr>
      <th width="2287" scope="col"><p class="style8"><a href="homePage.php">HomePage</a> ||<a href="main.php">Page 1</a>|| <a href="main2.php">Page 2 </a> || <a href="login.php">Adminstraion</a> </p></th>
    </tr>
  </table>
  <p><span class="style8"><a href="homePage.php"></a></span></p>
  <table width="2245" height="87" border="1">
    <tr>
      <td width="2174" height="81"><div align="center">
        <p class="style3">Main Content</p>
      </div></td>
    </tr>
  </table>
  <table width="2174" height="512" border="1">
    <tr>
      <td width="913"><p class="style7">1. Emotional Bonds</p>
        <p class="style6">Modern companion robots are designed to respond to human emotions in natural and comforting ways. They can:<br />
  &bull; Recognize facial expressions and tone of voice<br />
  &bull; Understand basic emotional states like happiness, stress, or worry<br />
  &bull; Respond empathetically to provide reassurance or companionship</p>
      <p class="style6">These emotional interactions help reduce feelings of loneliness and create a sense of connection, especially for individuals who need consistent social interaction. Over time, people may begin to trust these robots as reliable companions who listen and respond without judgment.</p></td>
      <td width="1245"><div align="center"><img src="Photos/newemotional.jpg" width="417" height="432" /></div></td>
    </tr>
    <tr>
      <td height="261"><p class="style7">2. Family Integration</p>
        <p class="style6">Companion robots are expected to become familiar and useful members of modern families. Their roles may include:<br />
  &bull; Helping organize daily routines and reminding family members of important tasks<br />
  &bull; Supporting children through educational games and interactive learning<br />
  &bull; Assisting older adults by monitoring their well-being and notifying relatives if needed</p>
      <p class="style6">With these capabilities, companion robots could act as &ldquo;supportive family assistants,&rdquo; contributing to smoother communication and coordination within the household. Their presence may strengthen family connections by reducing stress and helping manage daily responsibilities.</p></td>
      <td><div align="center"><img src="photos/images.jpg" width="422" height="371" /></div></td>
    </tr>
  </table>
</div>
<table width="2283" height="87" border="1">
  <tr>
    <td width="2272" height="81"><div align="center">
      <p align="right" class="style3"><img src="Photos/MainLogo.jpg" width="128" height="134" /></p>
    </div></td>
  </tr>
</table>
<p align="center">&nbsp;</p>
</body>
</html>
