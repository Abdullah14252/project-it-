<?php require_once('Connections/DBproject1.php'); ?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['textfield'])) {
  $loginUsername=$_POST['textfield'];
  $password=$_POST['textfield2'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "AdminStrator.php";
  $MM_redirectLoginFailed = "Field.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_DBproject1, $DBproject1);
  
  $LoginRS__query=sprintf("SELECT username, password FROM usersinfo WHERE username='%s' AND password='%s'",
    get_magic_quotes_gpc() ? $loginUsername : addslashes($loginUsername), get_magic_quotes_gpc() ? $password : addslashes($password)); 
   
  $LoginRS = mysql_query($LoginRS__query, $DBproject1) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style4 {
	font-size: 24px;
	color: #000000;
}
.style5 {font-size: 24px}
.style9 {font-size: 36px; color: #00254A; }
.style10 {
	font-size: 36px;
	font-weight: bold;
	color: #00254A;
}
.style12 {font-size: 36px}
.style3 {	font-size: 36pt;
	color: #00254A;
	font-family: "Times New Roman", Times, serif;
}
-->
</style>
</head>

<body>
<div align="center" class="style1">
   <table width="1000" cellspacing="2">
     <tr>
       <th scope="col"><p class="style8"><a href="homePage.php">HomePage</a> ||<a href="main.php">Page 1</a>|| <a href="main2.php">Page 2 </a> || <a href="login.php">Adminstraion</a> </p></th>
     </tr>
     <tr>
       <th scope="col"><p class="style5">&nbsp;</p></th>
     </tr>
   </table>
   <p class="style9">Enter your name and password to log in </p>
</div>
 <table width="2305" border="1">
   <tr>
     <td height="39"><form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
       <label>
       <div align="center" class="style4"><span class="style10">Name</span>     
         <input name="textfield" type="text" class="style4" />
         <br />
       </div>
       <div align="center"><span class="style4"><span class="style10">Password</span>
          <input name="textfield2" type="text" class="style4" value="" />
         </span> <br />
         <br />
         <span class="style12"><strong>Log in</strong>
          <input name="Submit" type="submit" class="style4" value="Submit" />
         </span></div>
       </label>
                    </form>
     </td>
   </tr>
 </table>
 <table width="2283" height="87" border="1">
   <tr>
     <td width="2272" height="81"><div align="center">
         <p align="right" class="style3"><img src="Photos/MainLogo.jpg" width="128" height="134" /></p>
     </div></td>
   </tr>
 </table>
 </body>
</html>
