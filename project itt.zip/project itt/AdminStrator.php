<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style4 {
	font-size: 36px;
	color: #00254A;
}
.style5 {color: #00254A}
.style6 {font-size: 36pt;
	color: #00254A;
	font-family: "Times New Roman", Times, serif;
}
-->
</style>
</head>

<body>
<div align="center" class="style1">
  <p class="style5">Adminstrator Page</p>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="2301" height="55" border="1">
  <tr>
    <td><p align="center" class="style4">DataBase Location : PHPMYADMIN</p>
    <p align="center" class="style5">&nbsp;</p>
    <p align="center" class="style4">DataBase Name : userinfo </p>
    <p align="center" class="style5">&nbsp;</p>
    <p align="center" class="style4"> accounts in website: </p>
    <p align="center" class="style4">user1:1234</p>
    <p align="center" class="style4">user2:4321</p></td>
  </tr>
</table>
<div align="center">
  <p align="right" class="style6"><img src="Photos/MainLogo.jpg" width="128" height="134" /></p>
</div>
</body>
</html>
