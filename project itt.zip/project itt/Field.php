<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 24px}
.style3 {font-size: 36px; font-weight: bold; }
.style4 {	font-size: 36pt;
	color: #00254A;
	font-family: "Times New Roman", Times, serif;
}
-->
</style>
</head>

<body>
<table width="2290" border="1">
  <tr>
    <td><div align="center">
      <p class="style3">Invalid name or password , please try again :( </p>
      <p class="style1">&nbsp;</p>
      <p class="style1"><a href="login.php" class="style3">Log in again </a></p>
    </div></td>
  </tr>
</table>
<table width="2283" height="87" border="1">
  <tr>
    <td width="2272" height="81"><div align="center">
      <p align="right" class="style4"><img src="Photos/MainLogo.jpg" width="128" height="134" /></p>
    </div></td>
  </tr>
</table>
</body>
</html>
